# zombey_blender_exporter
Blender exporter for the zombye-engine model format
